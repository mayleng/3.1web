﻿namespace SimplCommerce.Module.Catalog.Models
{
    public enum ProductLinkType
    {
        Super = 1,

        Related = 2,

        CrossSell = 3,

        UpSell = 4
    }
}
