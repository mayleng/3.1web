﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductDetailCategory
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public string Slug { get; set; }
    }
}
