﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductOptionDisplay
    {
        public string Value { get; set; }

        public string DisplayType { get; set; }
    }
}
