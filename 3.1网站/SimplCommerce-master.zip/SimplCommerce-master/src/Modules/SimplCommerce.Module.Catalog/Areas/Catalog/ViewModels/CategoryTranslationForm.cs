﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class CategoryTranslationForm
    {
        public string DefaultCultureName { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}
