﻿using SimplCommerce.Module.Core.Areas.Core.ViewModels;

namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductWidgetForm : WidgetFormBase
    {
        public ProductWidgetSetting Setting { get; set; }
    }
}
