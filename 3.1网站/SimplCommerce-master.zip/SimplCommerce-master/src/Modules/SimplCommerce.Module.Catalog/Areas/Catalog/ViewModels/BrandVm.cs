﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class BrandVm : BrandForm
    {
        public long Id { get; set; }
    }
}
