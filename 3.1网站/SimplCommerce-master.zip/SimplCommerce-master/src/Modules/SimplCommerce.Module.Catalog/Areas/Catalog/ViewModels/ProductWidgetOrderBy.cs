﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public enum ProductWidgetOrderBy
    {
        Newest,

        BestSelling,

        Discount
    }
}
