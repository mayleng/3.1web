﻿namespace SimplCommerce.Module.Contacts.Areas.Contacts.ViewModels
{
    public class ContactAreaVm
    {
        public long Id { get; set; }

        public string Name { get; set; }
    }
}
