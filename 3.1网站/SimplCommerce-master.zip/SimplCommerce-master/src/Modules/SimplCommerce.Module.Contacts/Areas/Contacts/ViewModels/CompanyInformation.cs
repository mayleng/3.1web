﻿namespace SimplCommerce.Module.Contacts.Areas.Contacts.ViewModels
{
    public class CompanyInformation
    {
        public string Name { get; set; }
        
        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string FaxNumber { get; set; }

        public string Address { get; set; }
    }
}
