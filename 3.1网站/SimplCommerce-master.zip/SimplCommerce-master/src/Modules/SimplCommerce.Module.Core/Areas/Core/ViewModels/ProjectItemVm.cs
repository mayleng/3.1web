﻿namespace SimplCommerce.Module.Core.Areas.Core.ViewModels
{
    public class ProjectItemVm
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public string ThumbnailUrl { get; set; }
    }
}
