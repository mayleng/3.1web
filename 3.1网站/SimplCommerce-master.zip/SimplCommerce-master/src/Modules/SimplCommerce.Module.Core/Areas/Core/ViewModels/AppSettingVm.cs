﻿namespace SimplCommerce.Module.Core.Areas.Core.ViewModels
{
    public class AppSettingVm
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }
}
