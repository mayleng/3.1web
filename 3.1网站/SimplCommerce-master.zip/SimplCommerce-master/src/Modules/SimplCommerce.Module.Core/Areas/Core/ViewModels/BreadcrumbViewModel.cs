﻿namespace SimplCommerce.Module.Core.Areas.Core.ViewModels
{
    public class BreadcrumbViewModel
    {
        public string Text { get; set; }

        public string Url { get; set; }
    }
}
