﻿namespace SimplCommerce.Module.Core.Models
{
    public class ThemeManifest
    {
        public string Name { get; set; }

        public string FullName { get; set; }

        public string DisplayName { get; set; }

        public string Version { get; set; }
    }
}
