﻿namespace SimplCommerce.Module.Core.Models
{
    public enum AddressType
    {
        Shipping,

        Billing
    }
}
